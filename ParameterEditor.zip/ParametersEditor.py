#################################################################
# Handcrafted at ZF -TCI, Hyderabad India
ToolName = 'ParametersEditor'
ToolRev = "2.0"
LastUpdatedOn = "8th April, 2022 "
LastUpdatedBy  = "Arun Kumar - Z0083520"

#################################################################

# Note : If any of the module throws error , please install the latest module on your system using pip command.

import tkinter
from tkinter import ttk
from tkinter import *
from tkinter import messagebox
from tkinter.filedialog import askopenfilename
import pandas as pd
from pandastable import Table
import copy
import sys
import os
import xml.etree.ElementTree as ET
from tkinter.scrolledtext import ScrolledText
from tkinter import font, END
from datetime import datetime


ProjectConfig = {}
BasicFormat = []
NumOfVariantsPresent = 0
VariantNames = []
FilePath = ""
ProjectVariantConfig = []
NewlyAddedParameter = {}
Filedata = []
DataConsiderationFlag = 1
PARAMETERS = []
ParameterAttributes = []
PARAMETERS_BaseCopy = []
PropertyFilterDisabled = []
PropertyFilterEnabled = []
TempDictValVal = []
AllParametersList = []
VariantsToFilterAway = []
ParameterFunctions = ["ALL PARAMETERS"]
ParameterAddedButValueNotEntered = 0
UnsavedChangesinDatabase = 0
LoadedFileMsgStatus = 0
ParameterAdd_InExitMode =1
ParameterDel_InExitMode =1
ParameterEdit_InExitMode =1
varAdd_InExitMode =1
varDel_InExitMode =1
varEdit_InExitMode =1
ProjConfig_InExitMode =1
StatusMessageCounter = 0

dataframeVariants = pd.DataFrame()
AlternativeParameterAtttrbKeys = {'name':'PARAMETER'     			,
                   'type':'DATATYPE'         		,
                   'dim_x':'PARAMETER_DIMx'     	,
                   'dim_y':'PARAMETER_DIMy'     	,
                   'resolution':'RESOLUTION'   		,
                   'unit':'UNIT'         			,
                   'min':'MIN'          			,
                   'max':'MAX'          			,
                   'cust_visible':'PARAMETER_CUSTVISIBLE',
                   'group':'FUNC_GROUP'       		,
                   'ddscaling':'PARAMETER_DDSCALING',
                   'address':'PARAMETER_ADDRESS',
                   'comments':'COMMENT'   }

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

IconFilepath = resource_path(r"Z1F_logo.ico")


GUITopFrame = tkinter.Tk()  # Update Text b/w Labels
GUITopFrame.config(bg="old lace")
GUITopFrame.title('Parameters Editor')
GUITopFrame.resizable(True, True)  # x,y resizabling disabled
#GUITopFrame.geometry('1000x550')
GUITopFrame.minsize(1000,500)
GUITopFrame.state("zoomed")
ParameterFileParsedStatus = 0

try:
    GUITopFrame.iconbitmap(IconFilepath)
except Exception as error:
    print(error)


def ErrorPrompt(ErrorType, message):
    messagebox.showwarning(ErrorType, message)





def ResetFields():
    global FilePath,Filedata,DataConsiderationFlag,ParameterFileParsedStatus,\
        ProjectConfig,BasicFormat,NumOfVariantsPresent,VariantNames,ProjectVariantConfig,NewlyAddedParameter,PARAMETERS,\
        PropertyFilterDisabled,PropertyFilterDisabled,PropertyFilterEnabled,StatusMessageCounter,\
        TempDictValVal,EditParameterButton,AllParametersList,VariantsToFilterAway,ParameterFunctions,GenerateButtonButton,ParseandDisplayButton,labelframe2,StatusBar

    ProjectConfig = {}
    BasicFormat = []
    NumOfVariantsPresent = 0
    VariantNames = []
    FilePath = ""
    ProjectVariantConfig = []
    NewlyAddedParameter = {}
    Filedata = []
    DataConsiderationFlag = 1
    StatusMessageCounter = 0
    PARAMETERS = []
    PropertyFilterDisabled = []
    PropertyFilterEnabled = []
    TempDictValVal = []
    AllParametersList = []
    VariantsToFilterAway = []
    ParameterFunctions.clear()
    ParameterFunctions = ["ALL PARAMETERS"]

    StatusBar.config(state=NORMAL)
    StatusBar.delete('0.0', END)
    StatusBar.config(state=DISABLED)

    ParameterFileParsedStatus = 0
    GenerateButtonButton.configure(bg="red4")
    ParseandDisplayButton.configure(bg="red4")
    EditParameterButton.configure(bg="red4")
    labelframe2.destroy()
    labelframe2 = LabelFrame(GUITopFrame, bg="old lace", fg="white")
    labelframe2.pack(fill=BOTH, expand=1)

    frame = tkinter.Frame(labelframe2)
    frame.pack(fill=BOTH, expand=1)
    df = pd.DataFrame(index=['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''], \
                      columns=['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''])
    PandasTable = Table(frame, dataframe=df, showtoolbar=False, showstatusbar=True)
    PandasTable.show()
    StatusUpdate("Reset - Parameters Tool Rev"+str(ToolRev))
    StatusUpdate("Browse/Select Parameter File to view and edit parameters.")



def extract(raw_string, start_marker, end_marker):
    start = raw_string.index(start_marker) + len(start_marker)
    end = raw_string.index(end_marker, start)
    return raw_string[start:end]




def StatusUpdate(msg):
    global StatusBar,StatusMessageCounter
    StatusMessageCounter+=1
    if len(msg.strip()) ==0:
        return
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    StatusBar.config(state=NORMAL)
    StatusBar.insert(END, "MSG:"+str(StatusMessageCounter)+" TimeStamp :"+str(current_time)+"\n"+msg + "\n\n")
    StatusBar.config(state=DISABLED)



def GenerateXML():
    global GenerateButtonButton,UnsavedChangesinDatabase,EditParameterButton,LoadedFileMsgStatus
    StatusUpdate("Generating parameter.xml ..")

    for parameter in PARAMETERS:
        Flag_No_Variant_ValueEntered = 0
        for variant in VariantNames:

            try:
                if str(parameter[variant]) or str(parameter[variant]).strip():
                    Flag_No_Variant_ValueEntered +=1
                else :
                    Flag_No_Variant_ValueEntered +=0



                if "Indx" in str(parameter[variant]):
                    EditParameterButton.configure(bg="red")
                    ErrorPrompt("Input Error", "Please EDIT Valid Values for Parameter:  " + str(parameter[
                                                                                                     'PARAMETER']) + "  in applicable Variants. \n Eg. Substitute Indx to Valid Values(Array Data) or Fill in Blank values(Single Data)")
                    StatusUpdate("Error : Parameter file generation aborted.")
                    return

            except: pass
            if Flag_No_Variant_ValueEntered == 0 :
                EditParameterButton.configure(bg="red")
                ErrorPrompt("Input Error", "Please EDIT Valid Values for Parameter:  " + str(parameter[

                                                                                                 'PARAMETER']) + "\nEg. Fill in Blank values(Single Data) for at-least one Variant")
                StatusUpdate("Error : Parameter file generation aborted.")
                return
    if ParameterAddedButValueNotEntered == 1 :
        ErrorPrompt("Operation Missed", "Please EDIT valid Values for all Variant for newly Added parameter")
        StatusUpdate("Generation failed due to invalid data in parameter variant.")
        return

    if ParameterFileParsedStatus==0:
        StatusUpdate("Error : Parameter file generation aborted. No database loaded.")
        ErrorPrompt("Invalid Operation", "Please parse parameters file(.xml) before re-generating parameters file")

        return

    def UpdateVarinatLines() :
        datatemp1 = list()
        datatemp1.append("  <Variant_List>\n")
        #StatusUpdate("Updating Variant details ..")

        for variantinfo in ProjectVariantConfig:
            #variantInfoTemp = ""
            variantInfoTemp = "    <Filevariant"
            for key in variantinfo.keys():
                variantInfoTemp += " "+key+"="+'"'+str(variantinfo[key])+'"'

            variantInfoTemp += " />\n"
            datatemp1.append(variantInfoTemp)
            #print(variantInfoTemp)

            #datatemp1.append('''    <Filevariant name="{}" patchlevel="{}" Description="{}" />\n'''.format(element['name'],element['patchlevel'],element['Description']))


        datatemp1.append("  </Variant_List>\n")
        return datatemp1


    def UpdateParameterLines() :
        datatemp1 = list()
        PercentageCount = 0
        for parameter in PARAMETERS:
            PercentageCount +=1
            #StatusUpdate("Processing Parameters: " + str(int((PercentageCount/len(PARAMETERS))*100)) +"% done")

            datatemp2 = list()
            ParamAttribLine = "  <Parameter"
            #print(ParameterAttributes)
            for key in ParameterAttributes:
                if (parameter[AlternativeParameterAtttrbKeys[str(key)]]) != "NA":
                    #KeyVal = str(parameter[AlternativeParameterAtttrbKeys[str(key)]]).encode("unicode_escape").decode("utf-8").replace(r"\n","&#xA;").replace(r"\r","&#xD;")

                    KeyVal = parameter[AlternativeParameterAtttrbKeys[str(key)]]
                    attribVal = '''{}'''.format(KeyVal)
                    #attribVal=attribVal.replace("\n","&#xA;").replace("\r","&#xD;")
                   # print(attribVal)
                    ParamAttribLine += " "+str(key)+"="+'''"'''+ attribVal+'''"'''
            ParamAttribLine+=">\n"
            #print(ParamAttribLine)
            datatemp2.append(ParamAttribLine)


            #print(datatemp2)
            #datatemp2.append('''  <Parameter name="{}" type="{}" dim_x="{}" dim_y="{}" resolution="{}" unit="{}" min="{}" max="{}" cust_visible="{}" group="{}" ddscaling="{}" comments="{}" address="{}">\n'''.format(parameter['PARAMETER'],parameter['DATATYPE'],parameter['PARAMETER_DIMx'],parameter['PARAMETER_DIMy'],parameter['RESOLUTION'],parameter['UNIT'],parameter['MIN'],parameter['MAX'],parameter['PARAMETER_CUSTVISIBLE'],parameter['FUNC_GROUP'],parameter['PARAMETER_DDSCALING'],parameter['COMMENT'],parameter['PARAMETER_ADDRESS']))

            for variant in VariantNames:
                if variant in parameter.keys():
                    q = 0

                    if (int(parameter['PARAMETER_DIMx']) == 1) and (int(parameter['PARAMETER_DIMy']) == 1):
                        if str(str(parameter[variant]).replace(" ","")) or str(str(parameter[variant]).replace(" ","")).strip():
                            datatemp2.append('''    <Linevector variant="{}">\n'''.format(str(variant)))
                            datatemp2.append('''      <Scalar value="{}" />\n'''.format(str(parameter[variant])))
                            datatemp2.append('''    </Linevector>\n''')


                    if (int(parameter['PARAMETER_DIMx']) > 1) or (int(parameter['PARAMETER_DIMy']) > 1):
                        if variant in parameter.keys():

                            ValueSplit = str(parameter[variant]).replace("[","").replace("]","").replace(" ","").split(",")
                            str(parameter[variant])


                            if (int(parameter['PARAMETER_DIMx']) > 1) and (int(parameter['PARAMETER_DIMy']) == 1):
                                if str(ValueSplit[q]) or str(ValueSplit[q]).strip():
                                    datatemp2.append('''    <Linevector variant="{}">\n'''.format(str(variant)))
                                    q = 0
                                 
                                    for i in range(int(parameter['PARAMETER_DIMx'])):
                                        try: datatemp2.append('''      <Scalar value="{}" />\n'''.format(str(ValueSplit[q])))
                                        except:
                                            ErrorPrompt("Invalid Data detected",
                                                        "Parameter generation aborted and file has been corrupted , due to dataexisting in invalid format for parameter.")
                                            return
                                        q += 1
                                    datatemp2.append('''    </Linevector>\n''')

                            if (int(parameter['PARAMETER_DIMx']) == 1) and (int(parameter['PARAMETER_DIMy']) > 1):
                                if str(ValueSplit[q]) or str(ValueSplit[q]).strip():
                                    datatemp2.append('''    <Linevector variant="{}">\n'''.format(str(variant)))
                                    q = 0
                                    for i in range(int(parameter['PARAMETER_DIMy'])):
                                        try:datatemp2.append('''      <Scalar value="{}" />\n'''.format(str(ValueSplit[q])))
                                        except:
                                            ErrorPrompt("Invalid Data detected",
                                                        "Parameter generation aborted and file has been corrupted , due to dataexisting in invalid format for parameter.")
                                            return
                                        q += 1
                                    datatemp2.append('''    </Linevector>\n''')


                            if (int(parameter['PARAMETER_DIMx']) > 1) and (int(parameter['PARAMETER_DIMy']) > 1):
                                for j in range((int(parameter['PARAMETER_DIMx']))):
                                    if str(ValueSplit[q]) or str(ValueSplit[q]).strip():
                                        datatemp2.append('''    <Linevector variant="{}">\n'''.format(str(variant)))

                                        for i in range(int(parameter['PARAMETER_DIMy'])):
                                           
                                            try: datatemp2.append('''      <Scalar value="{}" />\n'''.format(str(ValueSplit[q])))
                                            except:
                                                ErrorPrompt("Invalid Data detected","Parameter generation aborted and file has been corrupted , due to dataexisting in invalid format for parameter.")
                                                return
                                            q+=1
                                        datatemp2.append('''    </Linevector>\n''')

            datatemp2.append('''  </Parameter>\n''')
            datatemp1.append(copy.deepcopy(datatemp2))
        datatemp1.append('''</Parameter_List>\n''')


        return datatemp1

    try: Outputfile = open(str(FilePath), 'w')
    except :
        StatusUpdate("Parameter file generation aborted. File has Read only access.")
        ErrorPrompt("Permission Error" , "Please grant system Write access to the file.Parameter file genration aborted.")
        return
    for line in BasicFormat:
        Outputfile.writelines(line)

    Outputfile.writelines(str('''<Parameter_List xmlns:xsi="{}" xsi:noNamespaceSchemaLocation="{}" projectname="{}" majorrevision="{}" minorrevision="{}" patchlevel="{}" customerfile="{}" file_for_merging="{}" baseaddress="{}" target="{}" s_record="{}" endianness="{}">\n'''.format(ProjectConfig['xlmns'],ProjectConfig['noNamespaceSchemaLocation'],ProjectConfig['projectname'],ProjectConfig['majorrevision'],ProjectConfig['minorrevision'],ProjectConfig['patchlevel'],ProjectConfig['customerfile'],ProjectConfig['file_for_merging'],ProjectConfig['baseaddress'],ProjectConfig['target'],ProjectConfig['s_record'],ProjectConfig['endianness'])))
   
    data = UpdateVarinatLines()
    for line in data:
        Outputfile.writelines(line)




    data = UpdateParameterLines()
    for line in data:
        Outputfile.writelines(line)

    Outputfile.close()
    UnsavedChangesinDatabase = 0
    GenerateButtonButton.configure(bg = "green")
    StatusUpdate("Parameter.xml generation Sucessfull.")
    StatusUpdate("Saved at : "+FilePath)
    LoadedFileMsgStatus = 0
    tkinter.messagebox.showinfo(title= "Generated", message=\
        "Parameters File Successfully Re-generated.\n\nPath: {}".format(FilePath))
    ParseParameter()
    return

def PropertyfilterUpdate():
    global PropertyFilterEnabled

    PropertyFilterEnabled.clear()

    PropertyFilterEnabled = ["PARAMETER"]

    if check_1.get():
        PropertyFilterEnabled.append('DATATYPE')
    if check_2.get():
        PropertyFilterEnabled.append('RESOLUTION')
    if check_3.get():
        PropertyFilterEnabled.append('UNIT')
    if check_12.get():
        PropertyFilterEnabled.append('MIN')
    if check_4.get():
        PropertyFilterEnabled.append('MAX')
    if check_5.get():
        PropertyFilterEnabled.append('COMMENT')
    if check_6.get():
        PropertyFilterEnabled.append('PARAMETER_DIMx')
    if check_7.get():
        PropertyFilterEnabled.append('PARAMETER_DIMy')
    if check_8.get():
        PropertyFilterEnabled.append('PARAMETER_CUSTVISIBLE')
    if check_9.get():
        PropertyFilterEnabled.append('PARAMETER_DDSCALING')
    if check_10.get():
        PropertyFilterEnabled.append('FUNC_GROUP')
    if check_11.get():
        PropertyFilterEnabled.append('PARAMETER_ADDRESS')


    for variant in VariantNames:
        if(variant not in VariantsToFilterAway):
            PropertyFilterEnabled.append(variant)




def FilterOutVariants():
    global PARAMETERS,VariantNames , AllParametersList , VariantsToFilterAway , VariantFilter

    #VariantFilter.clear()
    #NewVariantName = StringVar()
    if len(VariantNames) < 1 :
        ErrorPrompt("Input Error" , "Invalid Operation. Valid Parameters file (.xml) not yet parsed.\nPlease load the Parameters File.")
        return


    FilterOutVariant_GUI = Toplevel(labelframe1_3)
    #if FilterOutVariant_GUI.winfo_exists(): return
    FilterOutVariant_GUI.config(bg="old lace")
    FilterOutVariant_GUI.title("Filter Variants ")
    FilterOutVariant_GUI.resizable(True, True)  # x,y resizabling disabled
    FilterOutVariant_GUI.minsize(250, 320)
    #FilterOutVariant_GUI.geometry('250x380')
    try:
        FilterOutVariant_GUI.iconbitmap(IconFilepath)
    except:
        pass

    def CaliberateVariantFilter():

        VariantsToFilterAway.clear()
        for Variant in range(len(VariantNames)):
            if VariantFilter[Variant].get() == False:
                VariantsToFilterAway.append(VariantNames[Variant])

        pass

    VariantFilter = []
    RowNumb = 0
    ColNumb = 0
    for Variant in range(len(VariantNames)):

        VariantFilter.append(IntVar())

        if(len(VariantsToFilterAway) > 0):
            if (VariantNames[Variant] in VariantsToFilterAway):
                VariantFilter[Variant].set(0)
            else: VariantFilter[Variant].set(1)
        else : VariantFilter[Variant].set(1)

        if(ColNumb == 0):
            tkinter.Checkbutton(FilterOutVariant_GUI, text=VariantNames[Variant], variable=VariantFilter[Variant], onvalue=1, offvalue=0,
                                          command=CaliberateVariantFilter, bg="old lace").grid(row=RowNumb , column=0,
                                                                                                    sticky='W')
            ColNumb = 1
        else:
                tkinter.Checkbutton(FilterOutVariant_GUI, text=VariantNames[Variant], variable=VariantFilter[Variant],
                                    onvalue=1, offvalue=0,
                                    command=CaliberateVariantFilter, bg="old lace").grid(row=RowNumb, column=1,
                                                                                         sticky='W')
                ColNumb = 0
                RowNumb += 1







    def FilterOutVariantsCalibrateDisplay():
        UpdateFunctionFilter("")
        FilterOutVariant_GUI.destroy()
        return
    def Select_All():
        for VariantIndex in range(len(VariantNames)):
            VariantFilter[VariantIndex].set(1)
            CaliberateVariantFilter()
        return


    def SelectNone():

        for VariantIndex in range(len(VariantNames)):
            VariantFilter[VariantIndex].set(0)
            CaliberateVariantFilter()

        return




    tkinter.Button(FilterOutVariant_GUI, text="Filter", bg='red4', fg='white', command=FilterOutVariantsCalibrateDisplay).grid(row=RowNumb+3, column=0,
                                                                                                columnspan=1,
                                                                                                sticky='W',
                                                                                                padx=5, pady=5,
                                                                                                ipadx=5, ipady=2)
    tkinter.Button(FilterOutVariant_GUI, text="Select ALL", bg='floralwhite', fg='black',
                   command=Select_All).grid(row=RowNumb + 2, column=0,
                                                                   columnspan=1,
                                                                   sticky='W',
                                                                   padx=5, pady=5,
                                                                   ipadx=5, ipady=2)
    tkinter.Button(FilterOutVariant_GUI, text="De-select All", bg='floralwhite', fg='black',
                   command=SelectNone).grid(row=RowNumb + 2, column=1,
                                                                   columnspan=1,
                                                                   sticky='W',
                                                                   padx=5, pady=5,
                                                                   ipadx=5, ipady=2)

def filterparameters(tempdata):
    global AllParametersList
    tempdata2 = []
    tempdata8 = []
    AllParametersList.clear()
    tempdata2.clear()
    tempdata8.clear()
    for parameter1 in tempdata:
        AllParametersList.append(parameter1['PARAMETER'])
        try:
            if (str(FunctionFiltered.get()) == "ALL PARAMETERS") or (parameter1['FUNC_GROUP'] == str(FunctionFiltered.get())):
                tempdata2.append(parameter1)
            else:pass
        except: pass
    AllParametersList = sorted(AllParametersList)
    return tempdata2


def UpdateFunctionFilter(event):
    global TempDictValVal,AllParametersList
    TempDictValVal.clear()
    AllParametersList.clear()
    #StatusUpdate("Loading parameters ...")
   # StatusUpdate("Loading parameters file ...\n\t "+FilePath)
    #StatusUpdate("Loading:"+FilePath)
    if ParameterFileParsedStatus:
        argument = copy.deepcopy(PARAMETERS)
        for parameter1 in PARAMETERS:
            AllParametersList.append(parameter1['PARAMETER'])
        AllParametersList = sorted(AllParametersList)
        #TempDictValVal = filterparameters(argument)
        UpdateVisualTable(PARAMETERS)
    else :
        ErrorPrompt("Input Error", "Parameter file not yet parsed.\nPlease provide valid input before proceeding.")

def UpdateFunctionFilterCheckBox():
    UpdateFunctionFilter("")


def ParseParameter():

    global FilePath , ParameterFileParsedStatus,PARAMETERS,ParseandDisplayButton,ProjectVariantConfig,NumOfVariantsPresent,\
        VariantNames,BasicFormat,ParameterAddedButValueNotEntered,PARAMETERS_BaseCopy,ParameterAttributes


    PARAMETERS.clear()
    ProjectVariantConfig.clear()
    VariantNames.clear()
    BasicFormat.clear()
    ParameterAddedButValueNotEntered = 0
    GenerateButtonButton.configure(bg="red4")
    ParseandDisplayButton.configure(bg="red4")
   # print(FilePath)
    lines = []
    try:
        with open(str(FilePath)) as file_in:

            for line in file_in:
                lines.append(line)
    except:
        ErrorPrompt("Input Error" , "No Input file selected , xml Parsing aborted")
        StatusUpdate("Parameters file not Selected.")
        return


    ParameterFileParsedStatus = 0
    tree = ET.parse(FilePath)
    parameters = tree.getroot()
    #print(parameters.attrib)
    for param in parameters:
        elem = copy.deepcopy(param.attrib)
        tempParameterAttributes = list(elem.keys())
        if 'name' in elem.keys():
            for atrribute in tempParameterAttributes:
                if atrribute not in ParameterAttributes:
                    ParameterAttributes.append(atrribute)
    def extractValues(test_str):
        global PARAMETERS,NumOfVariantsPresent,VariantNames , FunctionFiltered,ParameterAttributes
        idx1 = test_str.index('<Parameter name=')
        idx2 = test_str.index('" type=')
        PARAMETER_NAME = test_str[idx1 + len('<Parameter name=') + 1: idx2]

        # XML process

        #ParameterAttributes_copyFalg = 0
        for param in parameters:
            elem = copy.deepcopy(param.attrib)
            #print(elem)
            if 'name' in elem.keys():
               # if ParameterAttributes_copyFalg ==0:


                #print(ParameterAttributes)
                    #ParameterAttributes_copyFalg = 1
                #print(ParameterAttributes)
                if str(elem['name']) == str(PARAMETER_NAME):

                    if 'type' in elem.keys():
                        PARAMETER_TYPE = elem['type']
                    else : PARAMETER_TYPE = "NA"

                    if 'dim_x' in elem.keys():
                        PARAMETER_DIMx = elem['dim_x']
                    else : PARAMETER_DIMx = "0"

                    if 'dim_y' in elem.keys():
                        PARAMETER_DIMy = elem['dim_y']
                    else : PARAMETER_DIMy = "0"

                    if 'resolution' in elem.keys():
                        PARAMETER_RESOLUTION = elem['resolution']
                    else : PARAMETER_RESOLUTION = "0"

                    if 'unit' in elem.keys():
                        #PARAMETER_UNIT = elem['unit']
                        try:
                            idx1 = test_str.index('unit=')
                            idx2 = test_str.index('" min')
                            PARAMETER_UNIT = test_str[idx1 + len('unit=') + 1: idx2]
                        except: PARAMETER_UNIT = "NA"
                    else : PARAMETER_UNIT = "NA"

                    if 'min' in elem.keys():
                        PARAMETER_MIN = elem['min']
                    else : PARAMETER_MIN = "NA"

                    if 'max' in elem.keys():
                        PARAMETER_MAX = elem['max']
                    else:
                        PARAMETER_MAX = "NA"

                    if 'cust_visible' in elem.keys():
                        PARAMETER_CUSTVISIBLE = elem['cust_visible']
                    else:
                        PARAMETER_CUSTVISIBLE = "NA"

                    if 'group' in elem.keys():
                        PARAMETER_GROUP = elem['group']

                        if PARAMETER_GROUP not in ParameterFunctions:
                            ParameterFunctions.append(PARAMETER_GROUP)

                    else:
                        PARAMETER_GROUP = "NA"

                    if 'ddscaling' in elem.keys():
                        PARAMETER_DDSCALING = elem['ddscaling']
                    else:
                        PARAMETER_DDSCALING = "NA"

                    if 'comments' in elem.keys():
                        #PARAMETER_COMMENT = str(elem['comments='])
                        try:
                            idx1 = test_str.index('comments=')
                            idx2 = test_str.index('" address')
                            PARAMETER_COMMENT = test_str[idx1 + len('comments=') + 1: idx2]
                        except:
                            try:
                                idx1 = test_str.index('comments=')
                                idx2 = test_str.index('">')
                                PARAMETER_COMMENT = test_str[idx1 + len('comments=') + 1: idx2]
                            except: PARAMETER_COMMENT = "NA"
                    else:
                        PARAMETER_COMMENT = "NA"

                    if 'address' in elem.keys():
                        PARAMETER_ADDRESS = elem['address']
                    else:
                        PARAMETER_ADDRESS = "NA"
                    continue

        # END XMLprocess



        def VariantSCAN(dataContainer):
            VariantCount = 0
            index2D = 0
            for element in dataContainer:
                if "<Linevector variant=" in element:
                    VariantCount += 1
                    if element.partition('<Linevector variant="')[2].partition('">')[0] not in VariantNames:
                        VariantNames.append(element.partition('<Linevector variant="')[2].partition('">')[0])

            Parameter_variant_data = {}
            VariantData_temp = []
            VariantData_tempXd = []
            VariantData_tempXdNested = []
            Variants_CurrentinElem = []
            Variants_CurrentinElemSET = []


            for element in dataContainer:
                if "<Scalar value=" in element:
                    VariantData_temp.append(element.partition('<Scalar value="')[2].partition('" />')[0])
                if "<Linevector variant=" in element:
                    Variants_CurrentinElem.append(element.partition('<Linevector variant="')[2].partition('">')[0])
                    if element.partition('<Linevector variant="')[2].partition('">')[0] not in Variants_CurrentinElemSET:
                        Variants_CurrentinElemSET.append(element.partition('<Linevector variant="')[2].partition('">')[0])
       
            if (int(PARAMETER_DIMx) == 1) and (int(PARAMETER_DIMy) == 1):
                for variant in range(len(Variants_CurrentinElem)):
                    Parameter_variant_data[str(Variants_CurrentinElem[variant])] = str(VariantData_temp[variant]).replace("'","")
            if ((int(PARAMETER_DIMx) > 1) and (int(PARAMETER_DIMy) == 1)) or \
                    ((int(PARAMETER_DIMx) == 1) and (int(PARAMETER_DIMy) > 1)):
                Temp_ArrayValue = []
                Arrayindex = 0
                if int(PARAMETER_DIMx) > 1:
                        for variant in Variants_CurrentinElem:
                            Temp_ArrayValue.clear()
                            for i in range(int(PARAMETER_DIMx)):
                                    Temp_ArrayValue.append(VariantData_temp[Arrayindex])
                                    Arrayindex +=1
                            Parameter_variant_data[str(variant)] = str(copy.deepcopy(Temp_ArrayValue)).replace("'","")
                if int(PARAMETER_DIMy) > 1:
                        for variant in Variants_CurrentinElem:
                            Temp_ArrayValue.clear()
                            for i in range(int(PARAMETER_DIMy)):
                                    Temp_ArrayValue.append(VariantData_temp[Arrayindex])
                                    Arrayindex +=1
                            Parameter_variant_data[str(variant)] = str(copy.deepcopy(Temp_ArrayValue)).replace("'","")

            if (int(PARAMETER_DIMx) > 1) and (int(PARAMETER_DIMy) > 1):


                for variant in Variants_CurrentinElemSET:
               

                    VariantData_tempXdNested.clear()
       
                    for j in range(int(PARAMETER_DIMy)):
                        VariantData_tempXd.clear()
                        for p in range(int(PARAMETER_DIMx)):
                            VariantData_tempXd.append(VariantData_temp[index2D])
                            #print(index2D)
                            index2D +=1
        
                        VariantData_tempXdNested.append(copy.deepcopy(VariantData_tempXd))

                
                    tempdata = copy.deepcopy(VariantData_tempXdNested)
                    Parameter_variant_data[str(variant)] = str(tempdata).replace("'","")
            index2D = 0







            return VariantCount , Parameter_variant_data

        Values = []
        VarinatDataReceived = {}
        param_index = lines.index(line)
        while "</Parameter>" not in lines[param_index + 1]:
            Values.append(lines[param_index + 1])
            param_index += 1
        NumOfVariantsPresent,VarinatDataReceived  = VariantSCAN(Values)
        ParameterValues = {'PARAMETER'        : PARAMETER_NAME,
                           'DATATYPE'         : PARAMETER_TYPE ,
                           'PARAMETER_DIMx'         : PARAMETER_DIMx,
                           'PARAMETER_DIMy'         : PARAMETER_DIMy ,
                           'RESOLUTION'   : PARAMETER_RESOLUTION  ,
                           'UNIT'         : PARAMETER_UNIT  ,
                           'MIN'          : PARAMETER_MIN  ,
                           'MAX'          : PARAMETER_MAX  ,
                           'PARAMETER_CUSTVISIBLE'  : PARAMETER_CUSTVISIBLE   ,
                           'FUNC_GROUP'        : PARAMETER_GROUP    ,
                           'PARAMETER_DDSCALING'    : PARAMETER_DDSCALING ,
                           'PARAMETER_ADDRESS'      : PARAMETER_ADDRESS ,
                           'COMMENT'      : PARAMETER_COMMENT}

        for key in VarinatDataReceived.keys():
            ParameterValues[key] = str(VarinatDataReceived[key]).strip("'")

        return ParameterValues


    def extractVariaintValues(test_str):

        global ProjectVariantConfig

        ProjectVariantConfig = []
        tree = ET.parse(FilePath)
        nodes = tree.getroot()
        for node in nodes:

            if str(node.tag) == "Variant_List":
                for child in node:
                    ProjectVariantConfig.append(child.attrib)
            # elem = copy.deepcopy(param.attrib)
            # tempParameterAttributes = list(elem.keys())
        #print(ProjectVariantConfig)

        return




    def extractProjectValues(test_str):

        global ProjectConfig

        idx1 = test_str.index(' xmlns:xsi="')
        idx2 = test_str.index('" xsi:noNamespaceSchemaLocation=')
        xlmns = test_str[idx1 + len(' xmlns:xsi=') + 1: idx2]

        idx1 = test_str.index('xsi:noNamespaceSchemaLocation=')
        idx2 = test_str.index('" projectname')
        noNamespaceSchemaLocation = test_str[idx1 + len('xsi:noNamespaceSchemaLocation=') + 1: idx2]

        idx1 = test_str.index('projectname=')
        idx2 = test_str.index('" majorrevision')
        projectname = test_str[idx1 + len('projectname=') + 1: idx2]

        idx1 = test_str.index('majorrevision=')
        idx2 = test_str.index('" minorrevision')
        majorrevision = test_str[idx1 + len('majorrevision=') + 1: idx2]

        idx1 = test_str.index('minorrevision=')
        idx2 = test_str.index('" patchlevel')
        minorrevision = test_str[idx1 + len('minorrevision=') + 1: idx2]

        idx1 = test_str.index('patchlevel=')
        idx2 = test_str.index('" customerfile')
        patchlevel = test_str[idx1 + len('patchlevel=') + 1: idx2]

        idx1 = test_str.index('customerfile=')
        idx2 = test_str.index('" file_for_merging')
        customerfile = test_str[idx1 + len('customerfile=') + 1: idx2]

        idx1 = test_str.index('file_for_merging=')
        idx2 = test_str.index('" baseaddress')
        file_for_merging = test_str[idx1 + len('file_for_merging=') + 1: idx2]

        idx1 = test_str.index('baseaddress=')
        idx2 = test_str.index('" target')
        baseaddress = test_str[idx1 + len('baseaddress=') + 1: idx2]


        idx1 = test_str.index('target=')
        idx2 = test_str.index('" s_record')
        target = test_str[idx1 + len('target=') + 1: idx2]

        try:
            idx1 = test_str.index('s_record=')
            idx2 = test_str.index('" endianness')
            s_record = test_str[idx1 + len('s_record=') + 1: idx2]
        except: s_record = "S2"
        try:
            idx1 = test_str.index('endianness=')
            idx2 = test_str.index('">')
            endianness = test_str[idx1 + len('endianness=') + 1: idx2]
        except: endianness = "little"

        ProjectConfig ={ 'xlmns'                     : xlmns,
                         'noNamespaceSchemaLocation' : noNamespaceSchemaLocation,
                         'projectname'               : projectname,
                         'majorrevision'             : majorrevision,
                         'minorrevision'             : minorrevision,
                          'patchlevel'                : patchlevel,
                          'customerfile'              : customerfile,
                          'file_for_merging'          : file_for_merging,
                          'baseaddress'               : baseaddress,
                          'target'                    : target,
                          's_record'                  : s_record,
                          'endianness'                : endianness}


        return


    CaptureformatFlag = 1
    for line in lines:
        myString = str(line)
        if CaptureformatFlag ==1 :
            if ("<Parameter_List " in line) :
                CaptureformatFlag = 0
                extractProjectValues(line)
            else : BasicFormat.append(line)
        if("    <Filevariant" in line):
            extractVariaintValues(line)

        if "<Parameter name" in line:
            try: PARAMETERS.append(extractValues(line))
            except:
                ErrorPrompt("Fatal Error", " Parsing of Input Parameter file failed. Ensure Proper input")
                break



    for parameter in range(len(PARAMETERS)):
        pass

    FunctionFiltered.configure(state = "enabled")
    FunctionFiltered.configure(values = ParameterFunctions)
    try:
        FunctionFiltered.current(0)
    except:
     
        pass
    FunctionFiltered.bind("<<ComboboxSelected>>", UpdateFunctionFilter)
    ParseandDisplayButton.configure(bg = "green")
    ParameterFileParsedStatus = 1
    PARAMETERS_BaseCopy = copy.deepcopy(PARAMETERS)
    UpdateFunctionFilter("")
    #StatusUpdate("Project: {},  Revision: ( {}, {} ) Maj/Min".format(str(ProjectConfig['projectname']),str(ProjectConfig['majorrevision']),str(ProjectConfig['minorrevision'])))


def testFunction():
    #return
    global FilePath,ParameterFileParsedStatus
    ListofFiles = os.listdir(r'C:\Users\Z0083520\Desktop\PramEdit\TestFiles')
    for file in range(len(ListofFiles)):
        try:

            FilePath = str("C:\\Users\Z0083520\\Desktop\\PramEdit\\TestFiles\\")
            FilePath += str(ListofFiles[file])
            #print(FilePath)
            ParseParameter()
            ParameterFileParsedStatus = 1
            try: GenerateXML()
            except: print("Failure: Generation_Readback")
        except:
            continue
def BrowseParameterFile():

    global FilePath,LoadedFileMsgStatus
    FilePath = str(askopenfilename(title='Select file to be edited '))
    StatusUpdate("Loading parameters file ...\n" + FilePath)
    if ".xml" not in FilePath:
        if len(FilePath) ==0:
            StatusUpdate("Parameters file selection aborted.")
            return
        StatusUpdate("Error: Wrong File format selected.")
        ErrorPrompt("Input file Error","Please select the valid input file.")
        FilePath = ""
        return
    LoadedFileMsgStatus = 0
    ParseParameter()



def TrimParameters_EDITCONFIGURATIONS():
    global PARAMETERS, VariantNames, AllParametersList ,ProjectConfig,ProjConfig_InExitMode


    if ProjConfig_InExitMode ==1:pass
    else:return

    if len(VariantNames) < 1:
        ErrorPrompt("Input Error", "Invalid Operation.Valid Parameters file (.xml) not yet parsed.\nPlease load the Parameters File first.")
        ParseandDisplayButton.configure(bg="red4")
        return
    UpdateProjectConfig_GUI = Toplevel(labelframe1_3)
    UpdateProjectConfig_GUI.config(bg="old lace")
    UpdateProjectConfig_GUI.title("Edit Project Parameter Configuration ")
    UpdateProjectConfig_GUI.resizable(True, True)  # x,y resizabling disabled
    UpdateProjectConfig_GUI.geometry('730x340')
    try:
        UpdateProjectConfig_GUI.iconbitmap(IconFilepath)
    except:
        pass
    ProjConfig_InExitMode = 0
    def ResetGUIclosureStatus():
        global ProjConfig_InExitMode
        ProjConfig_InExitMode = 1
        UpdateProjectConfig_GUI.destroy()

    UpdateProjectConfig_GUI.protocol("WM_DELETE_WINDOW", ResetGUIclosureStatus)

    Fetch_xmlns = StringVar()
    Fetch_xmlns.set(str(ProjectConfig['xlmns']))
    Fetch_xsi = StringVar()
    Fetch_xsi.set(str(ProjectConfig['noNamespaceSchemaLocation']))
    Fetch_ProjectName = StringVar()
    Fetch_ProjectName.set(str(ProjectConfig['projectname']))
    Fetch_MajorRev = StringVar()
    Fetch_MajorRev.set(str(ProjectConfig['majorrevision']))
    Fetch_MinorRev = StringVar()
    Fetch_MinorRev.set(str(ProjectConfig['minorrevision']))
    Fetch_SRecord = StringVar()
    Fetch_SRecord.set(str(ProjectConfig['s_record']))
    Fetch_CustFile = StringVar()
    Fetch_CustFile.set(str(ProjectConfig['customerfile']))
    Fetch_FileToMerge = StringVar()
    Fetch_FileToMerge.set(str(ProjectConfig['file_for_merging']))
    Fetch_BaseAddress = StringVar()
    Fetch_BaseAddress.set(str(ProjectConfig['baseaddress']))
    Fetch_Target = StringVar()
    Fetch_Target.set(str(ProjectConfig['target']))
    Fetch_Endianness = StringVar()
    Fetch_Endianness.set(str(ProjectConfig['endianness']))
    Fetch_Patch = StringVar()
    Fetch_Patch.set(str(ProjectConfig['patchlevel']))

    def TriggerUpdateFields():
        if ((len(str(Fetch_xmlns.get()).strip()) < 1 ) or
(len(str(Fetch_xsi.get()).strip()) < 1 ) or
(len(str(Fetch_ProjectName.get()).strip()) < 1 ) or
(len(str(Fetch_MajorRev.get()).strip()) < 1 ) or
(len(str(Fetch_MinorRev.get()).strip()) < 1 ) or
(len(str(Fetch_Patch.get()).strip()) < 1 ) or
(len(str(Fetch_CustFile.get()).strip()) < 1 ) or
(len(str(Fetch_FileToMerge.get()).strip()) < 1 ) or
(len(str(Fetch_BaseAddress.get()).strip()) < 1 ) or
(len(str(Fetch_Target.get()).strip()) < 1 ) or
(len(str(Fetch_SRecord.get()).strip()) < 1 ) or
(len(str(Fetch_Endianness.get()).strip()) < 1 )):
            ErrorPrompt( "Input Error" , "Please Fill in all/Valid details")
        else:
            ProjectConfig['xlmns'] = str(Fetch_xmlns.get()).strip()
            ProjectConfig['noNamespaceSchemaLocation'] = str(Fetch_xsi.get()).strip()
            ProjectConfig['projectname'] = str(Fetch_ProjectName.get()).strip()
            ProjectConfig['majorrevision'] = str(Fetch_MajorRev.get()).strip()
            ProjectConfig['minorrevision'] = str(Fetch_MinorRev.get()).strip()
            ProjectConfig['patchlevel'] = str(Fetch_Patch.get()).strip()
            ProjectConfig['customerfile'] = str(Fetch_CustFile.get()).strip()
            ProjectConfig['file_for_merging'] = str(Fetch_FileToMerge.get()).strip()
            ProjectConfig['baseaddress'] = str(Fetch_BaseAddress.get()).strip()
            ProjectConfig['target'] = str(Fetch_Target.get()).strip()
            ProjectConfig['s_record'] = str(Fetch_SRecord.get()).strip()
            ProjectConfig['endianness'] = str(Fetch_Endianness.get()).strip()
        StatusUpdate("Project configurations updated.")
        ResetGUIclosureStatus()
        return


    Label(UpdateProjectConfig_GUI, text="XML NamespaceSchema Ref", bg="old lace").grid(row=0, column=0, columnspan=1, sticky='W',
                                                                          padx=5,
                                                                          pady=5, ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="XML No-NamespaceSchema Ref", bg="old lace").grid(row=1, column=0, columnspan=1, sticky='W', padx=5,
                                                                     pady=5,
                                                                     ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Project Name", bg="old lace").grid(row=2, column=0, columnspan=1, sticky='W',
                                                                             padx=5,
                                                                             pady=5, ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Major Revision", bg="old lace").grid(row=3, column=0, columnspan=1, sticky='W',
                                                                             padx=5,
                                                                             pady=5, ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Minor Revision", bg="old lace").grid(row=4, column=0, columnspan=1, sticky='W', padx=5,
                                                                   pady=5,
                                                                   ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Patch level", bg="old lace").grid(row=0, column=2, columnspan=1, sticky='W', padx=5,
                                                                     pady=5,
                                                                     ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Customer File", bg="old lace").grid(row=0, column=2, columnspan=1,
                                                                               sticky='W',
                                                                               padx=5,
                                                                               pady=5, ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="File for Merging", bg="old lace").grid(row=1, column=2, columnspan=1, sticky='W',
                                                                          padx=5,
                                                                          pady=5, ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Base Address", bg="old lace").grid(row=2, column=2, columnspan=1, sticky='W', padx=5,
                                                                      pady=5,
                                                                      ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Target", bg="old lace").grid(row=3, column=2, columnspan=1, sticky='W',
                                                                          padx=5,
                                                                          pady=5, ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="SRecord format", bg="old lace").grid(row=5, column=0, columnspan=1, sticky='W', padx=5,
                                                                   pady=5,
                                                                   ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Byte Endianness", bg="old lace").grid(row=4, column=2, columnspan=1, sticky='W', padx=5,
                                                                   pady=5,
                                                                   ipadx=5, ipady=2)
    Label(UpdateProjectConfig_GUI, text="Patch Level", bg="old lace").grid(row=5, column=2, columnspan=1, sticky='W', padx=5,
                                                                   pady=5,
                                                                   ipadx=5, ipady=2)

    Label(UpdateProjectConfig_GUI, text=" ", bg="old lace").grid(row=7, column=0, columnspan=1, sticky='W', padx=5,
                                                                   pady=5,
                                                                   ipadx=5, ipady=2)


    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_xmlns, width=30).grid(row=0, column=1, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_xsi, width=30).grid(row=1, column=1, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_ProjectName, width=30).grid(row=2, column=1, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_MajorRev, width=30).grid(row=3, column=1, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_MinorRev, width=30).grid(row=4, column=1, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_SRecord, width=30).grid(row=5, column=1, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_CustFile, width=30).grid(row=0, column=3, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_FileToMerge, width=30).grid(row=1, column=3, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_BaseAddress, width=30).grid(row=2, column=3, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_Target, width=30).grid(row=3, column=3, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_Endianness, width=30).grid(row=4, column=3, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateProjectConfig_GUI, textvariable=Fetch_Patch, width=30).grid(row=5, column=3, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)

    Button(UpdateProjectConfig_GUI, text=' Cancel ', bg="red4", fg="white", command=ResetGUIclosureStatus).grid(row=8,
                                                                                                          column=1,
                                                                                                          columnspan=1,
                                                                                                          sticky='W',
                                                                                                          padx=5,
                                                                                                          pady=5,
                                                                                                          ipadx=5,
                                                                                                          ipady=2)
    Button(UpdateProjectConfig_GUI, text=' Save and Close ', bg="red4", fg="white",
           command=TriggerUpdateFields).grid(row=8,
                                                         column=0,
                                                         columnspan=1,
                                                         sticky='W',
                                                         padx=5,
                                                         pady=5,
                                                         ipadx=5,
                                                         ipady=2)





def TrimParameters_ADDVARIANT():
    global PARAMETERS,VariantNames,ProjectVariantConfig,varAdd_InExitMode

    if varAdd_InExitMode ==1: pass
    else: return

    if ParameterFileParsedStatus == 0:
        ErrorPrompt("Input Error", "Invalid Operation. Valid Parameters file (.xml) not yet parsed.\nPlease load the Parameters File.")
        return

    NewVariantName = StringVar()
    NewVariantNameComment = StringVar()

    ADDVariant_GUI = Toplevel(labelframe1_3)
    ADDVariant_GUI.config(bg="old lace")
    ADDVariant_GUI.title("Add Variant ")
    ADDVariant_GUI.resizable(True, True)  # x,y resizabling disabled
    ADDVariant_GUI.minsize(380, 187)
    #ADDVariant_GUI.geometry('380x171')
    try:
        ADDVariant_GUI.iconbitmap(IconFilepath)
    except:
        pass
    varAdd_InExitMode = 0

    def ResetGUIclosureStatus():
        global varAdd_InExitMode
        varAdd_InExitMode = 1
        ADDVariant_GUI.destroy()

    ADDVariant_GUI.protocol("WM_DELETE_WINDOW", ResetGUIclosureStatus)

    Label(ADDVariant_GUI, text="  ", bg="old lace").grid(column=0, row=0)

    Label(ADDVariant_GUI , text = "Select base Variant : ",bg="old lace").grid(row=1, column=0, columnspan=1, sticky='W', padx=5,
                                                                    pady=5, ipadx=5, ipady=2)
    Label(ADDVariant_GUI , text = "New Variant Name : ",bg="old lace").grid(row=2, column=0, columnspan=1, sticky='W', padx=5,
                                                                    pady=5, ipadx=5, ipady=2)
    Label(ADDVariant_GUI , text = "New Variant Comment : ",bg="old lace").grid(row=3, column=0, columnspan=1, sticky='W', padx=5,
                                                                    pady=5, ipadx=5, ipady=2)

    Label(ADDVariant_GUI, text=" ", bg="old lace").grid(row=4)
    ParametersOptions = ttk.Combobox(ADDVariant_GUI, values=sorted(VariantNames) , width = 29 )
    ParametersOptions.grid(column=1, row=1)
    try:ParametersOptions.current(0)
    except: ErrorPrompt("Error" , "Error fetching VariantNames and render GUI , Please Re-parse the Parameters input file")


    Entry(ADDVariant_GUI, textvariable=NewVariantName, width=30).grid(row=2, column=1, columnspan=1, sticky='W', padx=5,
                                                                    pady=5, ipadx=5, ipady=2)
    Entry(ADDVariant_GUI, textvariable=NewVariantNameComment, width=30).grid(row=3, column=1, columnspan=1, sticky='W', padx=5,
                                                                    pady=5, ipadx=5, ipady=2)



    def ADD_Variant():

        import re


        if str(ParametersOptions.get()).strip() not in VariantNames:
            ErrorPrompt("Invalid Input" , "Invalid Variant name provided , Variant delition aborted. ")
            return
        if re.match('^[0-9]*$', str(NewVariantName.get()).strip()):
            ErrorPrompt("Invalid Input" , "Invalid Variant Name provided. Mix ofAlphanumeric characters expected.\nVariant Addition aborted. ")
            return
        if len(NewVariantNameComment.get().strip()) < 1:
            ErrorPrompt("Invalid Input",
                        "Provide Input for Variant Comments.\nVariant Addition aborted. ")
            return
        for parameter in range(len(PARAMETERS)):
            try: PARAMETERS[parameter][str(NewVariantName.get()).strip()] = PARAMETERS[parameter][str(ParametersOptions.get()).strip()]
            except: pass

        VariantNames.append(str(NewVariantName.get()).strip())
        for var in ProjectVariantConfig:
            if var['name'] == str(ParametersOptions.get()).strip():
                tempdataVar = copy.deepcopy(var)
                tempdataVar['name'] = NewVariantName.get().strip()
                tempdataVar['patchlevel'] = len(VariantNames)-1
                tempdataVar['Description'] = NewVariantNameComment.get().strip()
                ProjectVariantConfig.append(tempdataVar)
                break
        #ProjectVariantConfig.append({'name':NewVariantName.get().strip(),
         #                           'patchlevel': len(VariantNames)-1,
         #                           'Description':NewVariantNameComment.get().strip()})
        temp = str(ParametersOptions.get()).strip()

  
        UpdateFunctionFilter("")
        ResetGUIclosureStatus()
        StatusUpdate("New Variant :" + str(temp)+" added successfuly.")
        messagebox.showinfo("Status Message", "New Variant :" + str(temp)+" added Successfuly.")
        return

    Button(ADDVariant_GUI, text=' Add Variant ', bg="red4", fg="white", command=ADD_Variant).grid(row=5, column=0,
                                                                                      columnspan=1,
                                                                                      sticky='W', padx=5,
                                                                                      pady=5, ipadx=5,
                                                                                      ipady=2)
    Button(ADDVariant_GUI, text='  Cancel  ', bg="red4", fg="white", command=ResetGUIclosureStatus).grid(row=5, column=1,
                                                                                                columnspan=1,
                                                                                                sticky='W',
                                                                                                padx=5, pady=5,
                                                                                                ipadx=5, ipady=2)



def TrimParameters_EDITVARIANT():
    global dataframeVariants,ProjectVariantConfig,varEdit_InExitMode

    if varEdit_InExitMode ==1: pass
    else: return

    if ParameterFileParsedStatus == 0:
        ErrorPrompt("Input Error", "Invalid Operation. Valid Parameters file (.xml) not yet parsed.\nPlease load the Parameters File.")
        return

    EDIT_Variant_GUI = Toplevel(labelframe1_3)
    EDIT_Variant_GUI.config(bg="old lace")
    EDIT_Variant_GUI.title("Edit Variant Attributes")
    EDIT_Variant_GUI.resizable(True, True)  # x,y resizabling disabled
    #EDIT_Variant_GUI.geometry('380x170')
    #EDIT_Variant_GUI.minsize(380, 187)
    varEdit_InExitMode = 0

    labelframe1_1_EDIT_Variant_GUI= LabelFrame(EDIT_Variant_GUI, text="Edit Variant Attributes in Table", bg="old lace",
                               fg="black")
    labelframe1_1_EDIT_Variant_GUI.pack(fill=BOTH, expand=1, side="top")
    labelframe1_2_EDIT_Variant_GUI = LabelFrame(EDIT_Variant_GUI, text="Save/Discard Changes", bg="old lace",
                                                fg="black")
    labelframe1_2_EDIT_Variant_GUI.pack(fill=BOTH, side="top")





    try:
        EDIT_Variant_GUI.iconbitmap(IconFilepath)
    except:
        pass

    def copyChanges():
        global ProjectVariantConfig,varEdit_InExitMode
        #print(ProjectVariantConfig)
        ProjectVariantConfig = list(dataframeVariants.T.to_dict().values())
        #print(ProjectVariantConfig)
        StatusUpdate("Variant attributes updated")
        EDIT_Variant_GUI.destroy()
        varEdit_InExitMode = 1

    def CancelChanges():
        global varEdit_InExitMode
        EDIT_Variant_GUI.destroy()
        varEdit_InExitMode = 1


    EDIT_Variant_GUI.protocol("WM_DELETE_WINDOW", CancelChanges)


    Button(labelframe1_2_EDIT_Variant_GUI, text='Save and Close', bg="red4", fg="white", command=copyChanges).grid(
        row=0, column=0,
        columnspan=1,
        sticky='W',
        padx=10,
        pady=5, ipadx=5,
        ipady=2)
    Button(labelframe1_2_EDIT_Variant_GUI, text='Cancel', bg="red4", fg="white", command=CancelChanges).grid(
        row=0, column=1,
        columnspan=1,
        sticky='W',
        padx=10,
        pady=5, ipadx=5,
        ipady=2)


    frame = tkinter.Frame(labelframe1_1_EDIT_Variant_GUI)
    frame.pack(fill=BOTH, expand=1)
    dataframeVariants = pd.DataFrame(ProjectVariantConfig)
    #print(dataframeVariants)
    PandasTable = Table(frame, dataframe=dataframeVariants, showtoolbar=False, showstatusbar=False)
    PandasTable.show()

    pass

def TrimParameters_DELVARIANT():

    global PARAMETERS,VariantNames ,ProjectVariantConfig,varDel_InExitMode

    if varDel_InExitMode ==1 : pass
    else : return

    if len(VariantNames) < 1 :
        ErrorPrompt("Input Error" , "Parameter Xml not yet parsed / No Variant exist in database. Operation aborted.")
        return

    DEL_Variant_GUI = Toplevel(labelframe1_3)
    DEL_Variant_GUI.config(bg="old lace")
    DEL_Variant_GUI.title("Delete Variant")
    DEL_Variant_GUI.resizable(True, True)  # x,y resizabling disabled
    DEL_Variant_GUI.geometry('380x170')
    DEL_Variant_GUI.minsize(380, 187)
    varDel_InExitMode = 0

    def ResetGUIclosureStatus():
        global varDel_InExitMode
        varDel_InExitMode = 1
        DEL_Variant_GUI.destroy()

    DEL_Variant_GUI.protocol("WM_DELETE_WINDOW", ResetGUIclosureStatus)


    try:
        DEL_Variant_GUI.iconbitmap(IconFilepath)
    except:
        pass
    Label(DEL_Variant_GUI, text="  ", bg="old lace").grid(column=0, row=0)
    Label(DEL_Variant_GUI , text = " Select Variant : ",bg="old lace").grid(column=0, row=1,sticky='W')
    Label(DEL_Variant_GUI, text="", bg="old lace").grid(column=0, row=2)
    ParametersOptions = ttk.Combobox(DEL_Variant_GUI, values=sorted(VariantNames) , width = 29 )
    ParametersOptions.grid(column=1, row=1)
    ParametersOptions.current(0)

    def DEL_Variant():


        if str(ParametersOptions.get()).strip() not in VariantNames:
            ErrorPrompt("Invalid Input" , "Invalid Variant name provided , Variant delition aborted. ")
            return
        for parameter in range(len(PARAMETERS)):
            if str(ParametersOptions.get()).strip() in PARAMETERS[parameter].keys():
                del PARAMETERS[parameter][str(ParametersOptions.get()).strip()]

        VariantNames.remove(str(ParametersOptions.get()).strip())
        temp = str(ParametersOptions.get()).strip()

        for ProjectVariantConfiguration in ProjectVariantConfig:
            if ProjectVariantConfiguration['name'] == str(ParametersOptions.get()).strip():
                #ProjectVariantConfig.pop(ProjectVariantConfiguration)

                ProjectVariantConfig.remove(ProjectVariantConfiguration)


        for i in range(len(ProjectVariantConfig)):
            ProjectVariantConfig[i]['patchlevel'] = str(i+1)



        UpdateFunctionFilter("")
        ResetGUIclosureStatus()
        StatusUpdate("Variant :" + str(temp)+" deleted successfuly.")
        messagebox.showinfo("Status Message", "Variant :" + str(temp)+" Deleted Successfuly.")
        return

    Button(DEL_Variant_GUI, text=' Delete Variant ', bg="red4", fg="white", command=DEL_Variant).grid(row=3, column=0,
                                                                                      columnspan=1,
                                                                                      sticky='W', padx=5,
                                                                                      pady=5, ipadx=5,
                                                                                      ipady=2)
    Button(DEL_Variant_GUI, text='  Cancel  ', bg="red4", fg="white", command=ResetGUIclosureStatus).grid(row=3, column=1,
                                                                                                columnspan=1,
                                                                                                sticky='W',
                                                                                                padx=5, pady=5,
                                                                                                ipadx=5, ipady=2)





def TrimParameters_DELPARAMETER():
    global PARAMETERS,ParameterDel_InExitMode

    if ParameterDel_InExitMode ==1: pass
    else:return


    if len(AllParametersList) < 1 :
        ErrorPrompt("Input Error" , "Invalid Operation. Valid Parameters file (.xml) not yet parsed.\nPlease load the Parameters File.")
        return
    DELparamGUI = Toplevel(labelframe1_3)
    DELparamGUI.config(bg="old lace")
    DELparamGUI.title("Delete Parameter")
    DELparamGUI.resizable(True, True)  # x,y resizabling disabled
    DELparamGUI.geometry('380x170')
    DELparamGUI.minsize(380, 187)
    try:
        DELparamGUI.iconbitmap(IconFilepath)
    except:
        pass
    
    ParameterDel_InExitMode = 0
    def ResetGUIclosureStatus():
        global ParameterDel_InExitMode
        ParameterDel_InExitMode = 1
        DELparamGUI.destroy()

    DELparamGUI.protocol("WM_DELETE_WINDOW", ResetGUIclosureStatus)

    Label(DELparamGUI, text="  ", bg="old lace").grid(column=0, row=0)
    Label(DELparamGUI , text = " Select Parameter : ",bg="old lace").grid(column=0, row=1,sticky='W')
    Label(DELparamGUI , text = "  ",bg="old lace").grid(column=0, row=2)
    Label(DELparamGUI , text = " ",bg="old lace").grid(column=0, row=3)
    Label(DELparamGUI, text="", bg="old lace").grid(column=0, row=2)
    ParametersOptions = ttk.Combobox(DELparamGUI, values=sorted(AllParametersList) , width = 36 )
    ParametersOptions.grid(column=1, row=1)
    ParametersOptions.current(0)
    def DeleParam():
        if str(ParametersOptions.get()).strip() in AllParametersList: pass
        else:
            ErrorPrompt("Input Error" , "Please provide Valid/Existing Parameter name. Ensure character case sensitivity.")
            return
        for parameter in range(len(PARAMETERS)):
            if (str(PARAMETERS[parameter]['PARAMETER']) == str(ParametersOptions.get()).strip()):
                PARAMETERS.pop(parameter)
                break
        UpdateFunctionFilter("")
        temp = str(ParametersOptions.get()).strip()
        ResetGUIclosureStatus()
        StatusUpdate("Parameter : " + str(temp)+"  deleted successfuly.")
        messagebox.showinfo("Status Message", "Parameter : " + str(temp)+"  Deleted Successfuly.")
        return
    Button(DELparamGUI, text=' Delete Parameter ', bg="red4", fg="white", command=DeleParam).grid(row=5, column=0,
                                                                                      columnspan=1,
                                                                                      sticky='W', padx=5,
                                                                                      pady=5, ipadx=5,
                                                                                      ipady=2)
    Button(DELparamGUI, text='  Cancel  ', bg="red4", fg="white", command=ResetGUIclosureStatus).grid(row=5, column=1,
                                                                                                columnspan=1,
                                                                                                sticky='W',
                                                                                                padx=5, pady=5,
                                                                                                ipadx=5, ipady=2)


def TrimParameters_EDITPARAMETER():
    global PARAMETERS, VariantNames, AllParametersList,\
        ParameterAddedButValueNotEntered,ParameterEdit_InExitMode,EditParameterButton


    if ParameterEdit_InExitMode ==1 :pass
    else:return

    if len(VariantNames) < 1:
        ErrorPrompt("Input Error", "Invalid Operation. Valid Parameters file (.xml) not yet parsed.\nPlease load the Parameters File.")
        return

    UpdateParameter_GUI = Toplevel(labelframe1_3)
    UpdateParameter_GUI.config(bg="old lace")
    UpdateParameter_GUI.title("Edit Parameter Values ")
    UpdateParameter_GUI.resizable(True, True)  # x,y resizabling disabled
    #UpdateParameter_GUI.geometry('800x510')
    try:
        UpdateParameter_GUI.iconbitmap(IconFilepath)
    except:
        pass

    ParameterEdit_InExitMode = 0
    def ResetGUIclosureStatus():
        global ParameterEdit_InExitMode
        ParameterEdit_InExitMode = 1
        UpdateParameter_GUI.destroy()

    UpdateParameter_GUI.protocol("WM_DELETE_WINDOW", ResetGUIclosureStatus)



    FetchADD_DATATYPE = StringVar()
    FetchADD_PARAMETER_DIMx = IntVar()
    FetchADD_PARAMETER_DIMy = IntVar()
    FetchADD_RESOLUTION = StringVar()
    FetchADD_UNIT = StringVar()
    FetchADD_MIN = StringVar()
    FetchADD_MAX = StringVar()
    FetchADD_PARAMETER_CUSTVISIBLE = StringVar()
    FetchADD_FUNC_GROUP = StringVar()
    FetchADD_PARAMETER_DDSCALING = StringVar()
    FetchADD_PARAMETER_ADDRESS = StringVar()
    FetchADD_COMMENT = StringVar()

    def TriggerUpdateFields(CurrentSelectedParameter):
        # global FetchADD_DATATYPE
        for parameters in PARAMETERS:
            if parameters["PARAMETER"] == str(ParameterNamesUpdateSelect.get()):
                FetchADD_DATATYPE.set(str(parameters["DATATYPE"]))
                FetchADD_PARAMETER_DIMx.set(parameters["PARAMETER_DIMx"])
                FetchADD_PARAMETER_DIMy.set(parameters["PARAMETER_DIMy"])
                FetchADD_RESOLUTION.set(str(parameters["RESOLUTION"]))
                FetchADD_UNIT.set(str(parameters["UNIT"]))
                FetchADD_MIN.set(str(parameters["MIN"]))
                FetchADD_MAX.set(str(parameters["MAX"]))
                FetchADD_PARAMETER_CUSTVISIBLE.set(str(parameters["PARAMETER_CUSTVISIBLE"]))
                FetchADD_FUNC_GROUP.set(str(parameters["FUNC_GROUP"]))
                FetchADD_PARAMETER_DDSCALING.set(str(parameters["PARAMETER_DDSCALING"]))
                FetchADD_PARAMETER_ADDRESS.set(str(parameters["PARAMETER_ADDRESS"]))
                FetchADD_COMMENT.set(str(parameters["COMMENT"]))
                for variant in range(len(VariantNames)):
                    try: ParameterData[variant].set(str(parameters[str(VariantNames[variant])]))
                    except KeyError: ParameterData[variant].set(str(" "))
                return

            elif str(ParameterNamesUpdateSelect.get()) not in AllParametersList:
                ErrorPrompt("Input Error",
                            "Selected / Entered Parameter name doesn't exist. Please provide Valid name.")
                return
        pass

    Label(UpdateParameter_GUI, text="Parameter Name", bg="old lace").grid(row=0, column=0, columnspan=1, sticky='W',
                                                                          padx=5,
                                                                          pady=5, ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Data Type", bg="old lace").grid(row=1, column=0, columnspan=1, sticky='W', padx=5,
                                                                     pady=5,
                                                                     ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Data Dimension(X)", bg="old lace").grid(row=2, column=0, columnspan=1, sticky='W',
                                                                             padx=5,
                                                                             pady=5, ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Data Dimension(Y)", bg="old lace").grid(row=3, column=0, columnspan=1, sticky='W',
                                                                             padx=5,
                                                                             pady=5, ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Resolution", bg="old lace").grid(row=4, column=0, columnspan=1, sticky='W', padx=5,
                                                                      pady=5,
                                                                      ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="SI Unit", bg="old lace").grid(row=5, column=0, columnspan=1, sticky='W', padx=5,
                                                                   pady=5,
                                                                   ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Max Value", bg="old lace").grid(row=1, column=2, columnspan=1, sticky='W', padx=5,
                                                                     pady=5,
                                                                     ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Min Value", bg="old lace").grid(row=6, column=2, columnspan=1, sticky='W', padx=5,
                                                                     pady=5,
                                                                     ipadx=5, ipady=2)

    Label(UpdateParameter_GUI, text="Customer Visibility", bg="old lace").grid(row=2, column=2, columnspan=1,
                                                                               sticky='W',
                                                                               padx=5,
                                                                               pady=5, ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Function Group", bg="old lace").grid(row=3, column=2, columnspan=1, sticky='W',
                                                                          padx=5,
                                                                          pady=5, ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="DD Scaling", bg="old lace").grid(row=4, column=2, columnspan=1, sticky='W', padx=5,
                                                                      pady=5,
                                                                      ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Memory Address", bg="old lace").grid(row=5, column=2, columnspan=1, sticky='W',
                                                                          padx=5,
                                                                          pady=5, ipadx=5, ipady=2)
    Label(UpdateParameter_GUI, text="Comment", bg="old lace").grid(row=6, column=0, columnspan=1, sticky='W', padx=5,
                                                                   pady=5,
                                                                   ipadx=5, ipady=2)

    Entry(UpdateParameter_GUI, textvariable=FetchADD_DATATYPE, width=30).grid(row=1, column=1, columnspan=1, sticky='W',
                                                                              padx=5,
                                                                              pady=5, ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_PARAMETER_DIMx, width=30).grid(row=2, column=1, columnspan=1,
                                                                                    sticky='W',
                                                                                    padx=5, pady=5, ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_PARAMETER_DIMy, width=30).grid(row=3, column=1, columnspan=1,
                                                                                    sticky='W',
                                                                                    padx=5, pady=5, ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_RESOLUTION, width=30).grid(row=4, column=1, columnspan=1,
                                                                                sticky='W',
                                                                                padx=5,
                                                                                pady=5, ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_UNIT, width=30).grid(row=5, column=1, columnspan=1, sticky='W',
                                                                          padx=5,
                                                                          pady=5, ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_MAX, width=30).grid(row=1, column=3, columnspan=1, sticky='W',
                                                                         padx=5,
                                                                         pady=5,
                                                                         ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_MIN, width=30).grid(row=6, column=3, columnspan=1, sticky='W',
                                                                         padx=5,
                                                                         pady=5,
                                                                         ipadx=5, ipady=2)

    Entry(UpdateParameter_GUI, textvariable=FetchADD_PARAMETER_CUSTVISIBLE, width=30).grid(row=2, column=3,
                                                                                           columnspan=1,
                                                                                           sticky='W', padx=5, pady=5,
                                                                                           ipadx=5,
                                                                                           ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_FUNC_GROUP, width=30).grid(row=3, column=3, columnspan=1,
                                                                                sticky='W',
                                                                                padx=5,
                                                                                pady=5, ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_PARAMETER_DDSCALING, width=30).grid(row=4, column=3, columnspan=1,
                                                                                         sticky='W',
                                                                                         padx=5, pady=5, ipadx=5,
                                                                                         ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_PARAMETER_ADDRESS, width=30,state = "disabled").grid(row=5, column=3, columnspan=1,
                                                                                       sticky='W',
                                                                                       padx=5, pady=5, ipadx=5, ipady=2)
    Entry(UpdateParameter_GUI, textvariable=FetchADD_COMMENT, width=30).grid(row=6, column=1, columnspan=1, sticky='W',
                                                                             padx=5,
                                                                             pady=5, ipadx=5, ipady=2)
    separator = ttk.Separator(UpdateParameter_GUI,orient=HORIZONTAL).grid(row=7,column=0,padx=20,columnspan=6, ipadx=350)
    RowNum = 8
    ParameterData = []

    Col = 0
    for variant in range(len(VariantNames)):
        ParameterData.append(StringVar())


        if Col ==0 :
            Entry(UpdateParameter_GUI, textvariable=ParameterData[variant], width=30).grid(row=RowNum, column=1,
                                                                                           columnspan=5,
                                                                                           sticky='W',
                                                                                           padx=5,
                                                                                           pady=5, ipadx=5, ipady=2)
            Label(UpdateParameter_GUI, text=str(VariantNames[variant]), bg="old lace").grid(row=RowNum, column=0,
                                                                                            columnspan=1, sticky='W',
                                                                                            padx=5,
                                                                                            pady=5,
                                                                                            ipadx=5, ipady=2)
            Col +=1
        else :
            Entry(UpdateParameter_GUI, textvariable=ParameterData[variant], width=30).grid(row=RowNum, column=3,
                                                                                           columnspan=5,
                                                                                           sticky='W',
                                                                                           padx=5,
                                                                                           pady=5, ipadx=5, ipady=2)
            Label(UpdateParameter_GUI, text=str(VariantNames[variant]), bg="old lace").grid(row=RowNum, column=2,
                                                                                            columnspan=1, sticky='W',
                                                                                            padx=5,
                                                                                            pady=5,
                                                                                            ipadx=5, ipady=2)
            Col=0
            RowNum += variant

    ParameterNamesUpdateSelect = ttk.Combobox(UpdateParameter_GUI, values=sorted(AllParametersList), width=33)
    ParameterNamesUpdateSelect.grid(row=0, column=1, columnspan=1, sticky='W',
                                    padx=5,
                                    pady=5, ipadx=5, ipady=2)
    ParameterNamesUpdateSelect.current(0)
    ParameterNamesUpdateSelect.bind("<<ComboboxSelected>>", TriggerUpdateFields)
    TriggerUpdateFields("")
    def TriggerUpdateFields2():
        TriggerUpdateFields("")
    def Update_Parameter():
        global EditParameterButton
        for parameterindex in range(len(PARAMETERS)):
            if PARAMETERS[parameterindex]["PARAMETER"] == str(ParameterNamesUpdateSelect.get()):
                PARAMETERS[parameterindex]['DATATYPE'] = str(FetchADD_DATATYPE.get())
                PARAMETERS[parameterindex]['PARAMETER_DIMx'] = str(FetchADD_PARAMETER_DIMx.get())
                PARAMETERS[parameterindex]['PARAMETER_DIMy'] = str(FetchADD_PARAMETER_DIMy.get())
                PARAMETERS[parameterindex]['RESOLUTION'] = str(FetchADD_RESOLUTION.get())
                PARAMETERS[parameterindex]['UNIT'] = str(FetchADD_UNIT.get())
                PARAMETERS[parameterindex]['MAX'] = str(FetchADD_MAX.get())
                PARAMETERS[parameterindex]['MIN'] = str(FetchADD_MIN.get())
                PARAMETERS[parameterindex]['PARAMETER_CUSTVISIBLE'] = str(FetchADD_PARAMETER_CUSTVISIBLE.get())
                PARAMETERS[parameterindex]['FUNC_GROUP'] = str(FetchADD_FUNC_GROUP.get())
                PARAMETERS[parameterindex]['PARAMETER_DDSCALING'] = str(FetchADD_PARAMETER_DDSCALING.get())
                PARAMETERS[parameterindex]['PARAMETER_ADDRESS'] = str(FetchADD_PARAMETER_ADDRESS.get())
                PARAMETERS[parameterindex]['COMMENT'] = str(FetchADD_COMMENT.get())
                StatusUpdate("Parameter:"+str(ParameterNamesUpdateSelect.get())+" attributes updated.")

                for variant in range(len(VariantNames)):
                    PARAMETERS[parameterindex][str(VariantNames[variant])] = str(ParameterData[variant].get())

        EditParameterButton.configure(bg="red4")
        UpdateFunctionFilter("")
        ResetGUIclosureStatus()
        ParameterAddedButValueNotEntered = 0
        return

    Label(UpdateParameter_GUI, text=" ", bg="old lace").grid(row=RowNum + 2, column=0, columnspan=1, sticky='W', padx=5,
                                                             pady=5,
                                                             ipadx=5, ipady=2)
    Button(UpdateParameter_GUI, text=' Save and Close ', bg="red4", fg="white", command=Update_Parameter).grid(
        row=RowNum + 2, column=0,
        columnspan=1,
        sticky='W', padx=5,
        pady=5, ipadx=5,
        ipady=2)
    Button(UpdateParameter_GUI, text='  Cancel  ', bg="red4", fg="white", command=ResetGUIclosureStatus).grid(
        row=RowNum + 2, column=1,
        columnspan=1,
        sticky='W',
        padx=5, pady=5,
        ipadx=5, ipady=2)
    Button(UpdateParameter_GUI, text=' Search ', bg="red4", fg="white", command=TriggerUpdateFields2).grid(
        row=0, column=2,
        columnspan=1,
        sticky='W',
        padx=5, pady=5,
        ipadx=5, ipady=2)


def TrimParameters_ADDPARAMETER():

    global ParameterAddedButValueNotEntered,ParameterAdd_InExitMode

    if ParameterAdd_InExitMode ==1: pass
    else: return


    if len(AllParametersList) < 1 :
        ErrorPrompt("Input Error" , "Invalid Operation. Valid Parameters file (.xml) not yet parsed.\nPlease load the Parameters File.")
        return

    ADDParameter_GUI = Toplevel(labelframe1_3)
    ADDParameter_GUI.config(bg="old lace")
    ADDParameter_GUI.title("Add New parameter")
    ADDParameter_GUI.resizable(True, True)  # x,y resizabling disabled
    ADDParameter_GUI.geometry('710x505')
    try:
        ADDParameter_GUI.iconbitmap(IconFilepath)
    except:
        pass
    ParameterAdd_InExitMode = 0

    def ResetGUIclosureStatus():
        global ParameterAdd_InExitMode
        ParameterAdd_InExitMode = 1
        ADDParameter_GUI.destroy()

    ADDParameter_GUI.protocol("WM_DELETE_WINDOW", ResetGUIclosureStatus)


    NewlyAddedParameter = {}
    FetchADD_PARAMETER = StringVar()
    FetchADD_DATATYPE = StringVar()
    FetchADD_PARAMETER_DIMx = IntVar()
    FetchADD_PARAMETER_DIMy = IntVar()
    FetchADD_RESOLUTION = StringVar()
    FetchADD_UNIT = StringVar()
    FetchADD_MAX = StringVar()
    FetchADD_MIN = StringVar()
    FetchADD_PARAMETER_CUSTVISIBLE = StringVar()
    FetchADD_FUNC_GROUP = StringVar()
    FetchADD_PARAMETER_DDSCALING = StringVar()
    FetchADD_PARAMETER_ADDRESS = StringVar()
    FetchADD_COMMENT = StringVar()

    def FetchData():
        try:
            if str(FetchADD_PARAMETER.get().strip()) in AllParametersList:
                ErrorPrompt("InputError", "Input Parameter Name already exist/saved in database.Please provide Unique Parameter name.\n Or , Add after deleting existing one.")
                return

            if ((len(str(FetchADD_PARAMETER.get())) == 0)
                    or (len(str(FetchADD_DATATYPE.get())) == 0)
                    or (((FetchADD_PARAMETER_DIMx.get())) == 0)
                    or (((FetchADD_PARAMETER_DIMy.get())) == 0)
                    or (len(str(FetchADD_RESOLUTION.get())) == 0)
                    or (len(str(FetchADD_UNIT.get())) == 0)
                    or (len(str(FetchADD_MAX.get())) == 0)
                    or (len(str(FetchADD_MIN.get())) == 0)
                    or (len(str(FetchADD_PARAMETER_CUSTVISIBLE.get())) == 0)
                    or (len(str(FetchADD_FUNC_GROUP.get())) == 0)
                    or (len(str(FetchADD_PARAMETER_DDSCALING.get())) == 0)
                    or (len(str(FetchADD_PARAMETER_ADDRESS.get())) == 0)
                    or (len(str(FetchADD_COMMENT.get())) == 0)):
                ErrorPrompt("InputError", "Fill in all/Valid parameter details")
                return
        except:
            ErrorPrompt("InputError", "Fill in Valid parameter details")
            return



        else:
            NewlyAddedParameter = {'PARAMETER': str(FetchADD_PARAMETER.get().strip()),
                                    'DATATYPE'         	: str(FetchADD_DATATYPE.get().strip()),
                                    'PARAMETER_DIMx'         : str(FetchADD_PARAMETER_DIMx.get()).strip(),
                                    'PARAMETER_DIMy'         : str(FetchADD_PARAMETER_DIMy.get()).strip(),
                                    'RESOLUTION'   			: str(FetchADD_RESOLUTION.get().strip()),
                                    'UNIT'        			: str(FetchADD_UNIT.get().strip()),
                                    'MIN'          			: str(FetchADD_MIN.get().strip()) ,
                                    'MAX'          			: str(FetchADD_MAX.get().strip()) ,
                                    'PARAMETER_CUSTVISIBLE'  : str(FetchADD_PARAMETER_CUSTVISIBLE.get().strip()) ,
                                    'FUNC_GROUP'        	    : str(FetchADD_FUNC_GROUP.get().strip()) ,
                                    'PARAMETER_DDSCALING'    : str(FetchADD_PARAMETER_DDSCALING.get().strip()),
                                    'PARAMETER_ADDRESS'      : str(FetchADD_PARAMETER_ADDRESS.get().strip()) ,
                                    'COMMENT'      			: str(FetchADD_COMMENT.get().strip())}
        Val = list()
        ValString = ""
        for Variant in VariantNames:
            Val.clear()
            Val = [["Indx"+str(m) for m in range(FetchADD_PARAMETER_DIMx.get())] for n in range(FetchADD_PARAMETER_DIMy.get())]

            if ((FetchADD_PARAMETER_DIMx.get())==1) and ((FetchADD_PARAMETER_DIMy.get())==1):
                ValString  = str(Val).replace("['Indx0']" , "").replace("[","").replace("]","").replace("'","")
            elif ((FetchADD_PARAMETER_DIMx.get())==1) or ((FetchADD_PARAMETER_DIMy.get())==1):
                ValString  = str(Val).replace("[[" , "[").replace("]]" , "]").replace("'","")

            else: ValString = str(Val).strip().replace("'","")
            NewlyAddedParameter[Variant] = copy.deepcopy(ValString)


        PARAMETERS.append(NewlyAddedParameter)
        UpdateFunctionFilter("")
        temp = str(FetchADD_PARAMETER.get().strip())
        ResetGUIclosureStatus()
        StatusUpdate("New Parameter :" + str(temp) + " added successfuly.")
        messagebox.showinfo("Status Update", "New Parameter :" + str(temp) + " added Successfuly.")
        
    

        ParameterAddedButValueNotEntered = 1
        return
  




    def ReplicateParameter():
        if str(ParametersOptionsList.get()).strip() not in AllParametersList:
            ErrorPrompt("Invalid Input","Invalid parameter name entered.\nEnter valid parameter , and ensure character case sensitivity.")
            return
        else:

            for parameter in PARAMETERS:
                if str(ParametersOptionsList.get()).strip() == parameter["PARAMETER"]:
                    FetchADD_DATATYPE.set(str(parameter["DATATYPE"]))
                    FetchADD_PARAMETER_DIMx.set(str(parameter["PARAMETER_DIMx"]))
                    FetchADD_PARAMETER_DIMy.set(str(parameter["PARAMETER_DIMy"]))
                    FetchADD_RESOLUTION.set(str(parameter["RESOLUTION"]))
                    FetchADD_UNIT.set(str(parameter["UNIT"]))
                    FetchADD_MAX.set(str(parameter["MAX"]))
                    FetchADD_MIN.set(str(parameter["MIN"]))
                    FetchADD_PARAMETER_CUSTVISIBLE.set(str(parameter["PARAMETER_CUSTVISIBLE"]))
                    FetchADD_FUNC_GROUP.set(str(parameter["FUNC_GROUP"]))
                    FetchADD_PARAMETER_DDSCALING.set(str(parameter["PARAMETER_DDSCALING"]))
                    #FetchADD_PARAMETER_ADDRESS.set(str(parameter["PARAMETER_ADDRESS"]))
                    FetchADD_COMMENT.set(str(parameter["COMMENT"]))
            return



    separator = ttk.Separator(ADDParameter_GUI, orient=VERTICAL).grid(row=0, column=2, rowspan=9, ipady=130 ,sticky='NW',pady = 5)
    Label(ADDParameter_GUI, text="Parameter Name", bg="old lace").grid(row=0, column=0, columnspan=1, sticky='W', padx=5,
                                                               pady=5, ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Data Type", bg="old lace").grid(row=1, column=0, columnspan=1, sticky='W', padx=5, pady=5,
                                                          ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Data Dimension(X)", bg="old lace").grid(row=2, column=0, columnspan=1, sticky='W', padx=5,
                                                                  pady=5, ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Data Dimension(Y)", bg="old lace").grid(row=3, column=0, columnspan=1, sticky='W', padx=5,
                                                                  pady=5, ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Resolution", bg="old lace").grid(row=4, column=0, columnspan=1, sticky='W', padx=5, pady=5,
                                                           ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="SI Unit", bg="old lace").grid(row=5, column=0, columnspan=1, sticky='W', padx=5, pady=5,
                                                        ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Min Value", bg="old lace").grid(row=6, column=0, columnspan=1, sticky='W', padx=5, pady=5,
                                                        ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Max Value", bg="old lace").grid(row=7, column=0, columnspan=1, sticky='W', padx=5, pady=5,
                                                          ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Customer Visibility", bg="old lace").grid(row=8, column=0, columnspan=1, sticky='W', padx=5,
                                                                    pady=5, ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Function Group", bg="old lace").grid(row=9, column=0, columnspan=1, sticky='W', padx=5,
                                                               pady=5, ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="DD Scaling", bg="old lace").grid(row=10, column=0, columnspan=1, sticky='W', padx=5, pady=5,
                                                           ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Memory Address", bg="old lace").grid(row=11, column=0, columnspan=1, sticky='W', padx=5,
                                                               pady=5, ipadx=5, ipady=2)
    Label(ADDParameter_GUI, text="Comment", bg="old lace").grid(row=12, column=0, columnspan=1, sticky='W', padx=5, pady=5,
                                                        ipadx=5, ipady=2)

    Label(ADDParameter_GUI, text="Replicate Values of the Parameter :", bg="old lace").grid(row=0, column=3, columnspan=1, sticky='W')

    Button(ADDParameter_GUI, text='<--  Copy  ', bg="red4", fg="white", command= ReplicateParameter).grid(row=2,
                                                                                                              column=3,
                                                                                                              columnspan=1,
                                                                                                              sticky='W')



    def ReplicateAddParamValues(event):
        pass
    ParametersOptionsList = ttk.Combobox(ADDParameter_GUI, values=sorted(AllParametersList), width=36)
    ParametersOptionsList.grid(column=3, row=1,sticky='W')
    ParametersOptionsList.current(0)
    ParametersOptionsList.bind("<<ComboboxSelected>>", ReplicateAddParamValues)



    Entry(ADDParameter_GUI, textvariable=FetchADD_PARAMETER, width=30).grid(row=0, column=1, columnspan=1, sticky='W', padx=5,
                                                                    pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_DATATYPE, width=30).grid(row=1, column=1, columnspan=1, sticky='W', padx=5,
                                                                   pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_PARAMETER_DIMx, width=30).grid(row=2, column=1, columnspan=1, sticky='W',
                                                                         padx=5, pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_PARAMETER_DIMy, width=30).grid(row=3, column=1, columnspan=1, sticky='W',
                                                                         padx=5, pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_RESOLUTION, width=30).grid(row=4, column=1, columnspan=1, sticky='W', padx=5,
                                                                     pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_UNIT, width=30).grid(row=5, column=1, columnspan=1, sticky='W', padx=5,
                                                               pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_MIN, width=30).grid(row=6, column=1, columnspan=1, sticky='W', padx=5, pady=5,
                                                              ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_MAX, width=30).grid(row=7, column=1, columnspan=1, sticky='W', padx=5, pady=5,
                                                              ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_PARAMETER_CUSTVISIBLE, width=30).grid(row=8, column=1, columnspan=1,
                                                                                sticky='W', padx=5, pady=5, ipadx=5,
                                                                                ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_FUNC_GROUP, width=30).grid(row=9, column=1, columnspan=1, sticky='W', padx=5,
                                                                     pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_PARAMETER_DDSCALING, width=30).grid(row=10, column=1, columnspan=1, sticky='W',
                                                                              padx=5, pady=5, ipadx=5, ipady=2)
    Entry(ADDParameter_GUI, textvariable=FetchADD_PARAMETER_ADDRESS, width=30,state = "disabled").grid(row=11, column=1, columnspan=1, sticky='W',
                                                                            padx=5, pady=5, ipadx=5, ipady=2)
    FetchADD_PARAMETER_ADDRESS.set(str("0x00"))


    Entry(ADDParameter_GUI, textvariable=FetchADD_COMMENT, width=85).grid(row=12, column=1, columnspan=4, sticky='W', padx=5,
                                                                  pady=5, ipadx=5, ipady=2)


    Button(ADDParameter_GUI, text=' Add Parameter  ', bg="red4", fg="white", command=FetchData).grid(row=13, column=0,
                                                                                      columnspan=1,
                                                                                      sticky='W', padx=5,
                                                                                      pady=5, ipadx=5,
                                                                                      ipady=2)
    Button(ADDParameter_GUI, text='  Cancel  ', bg="red4", fg="white", command=ResetGUIclosureStatus).grid(row=13, column=1,
                                                                                                columnspan=1,
                                                                                                sticky='W',
                                                                                                padx=5, pady=5,
                                                                                                ipadx=5, ipady=2)





labelframe1 = LabelFrame(GUITopFrame, text="", bg="old lace",
                         fg="white")
labelframe1.pack(fill=BOTH)

labelframe1_1 = LabelFrame(labelframe1, text="File Processing", bg="old lace",
                         fg="black")
labelframe1_1.pack(fill=BOTH,expand=1,side = "left")


labelframe1_2 = LabelFrame(labelframe1, text="Filters", bg="old lace",
                         fg="black")
labelframe1_2.pack(fill=BOTH,expand=1,side = "left")

labelframe1_3 = LabelFrame(labelframe1, text="Parameters Trimming", bg="old lace",
                         fg="black")
labelframe1_3.pack(fill=BOTH,expand=1,side = "left")
labelframe1_4 = LabelFrame(labelframe1, text="Messages Log", bg="old lace",
                         fg="black")

labelframe1_4.pack(fill=BOTH,expand=1,side = "left")

StatusBar = ScrolledText(labelframe1_4,width=40, height=7,background="white",foreground = "black")
StatusBar.pack(fill=BOTH,expand=1)


labelframe2 = LabelFrame(GUITopFrame, bg="old lace",fg="white")
labelframe2.pack(fill=BOTH, expand=1)


frame = tkinter.Frame(labelframe2)
frame.pack(fill=BOTH, expand=1)
df = pd.DataFrame(index = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''],\
                  columns = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''])
PandasTable = Table(frame, dataframe=df, showtoolbar=False, showstatusbar=True, dtype=object)
PandasTable.show()


ParseAndDisplayButtonLabel = Label(labelframe1_1, text="Select Parameter File", bg="old lace")
ParseAndDisplayButtonLabel.grid(columnspan=10,column=0,row=0,pady=5,padx=5,sticky='W')
ParseandDisplayButton = Button(labelframe1_1,font=("Segoe UI",9),text="    Browse ...     ", fg="white", bg="red4",
                      relief="raised",command = BrowseParameterFile)
ParseandDisplayButton.grid(row=0, column=1, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)

ResetButton = Button(labelframe1_1,font=("Segoe UI",9),text="Tool Reset", fg="white", bg="red3",
                      relief="raised",command = ResetFields)
ResetButton.grid(row=3, column=0, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)


#StatusBar = Label(labelframe1_1, text="Select Parameter File to view and edit parameters...",\
  #                fg="green", bg="old lace",width=43)
#StatusBar.grid(row=4, column=0, columnspan=20,sticky='W', pady=5, ipady=2)


GenerateButtonLabel = Label(labelframe1_1,font=("Segoe UI",9), text="Generate Parameters File", bg="old lace").grid(column=0,row=1,padx=5,sticky='W')
GenerateButtonButton = Button(labelframe1_1,font=("Segoe UI",9),text="Generate .XML", fg="white", bg="red4",
                      relief="raised",command = GenerateXML)
GenerateButtonButton.grid(row=1, column=1, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)


FunctionFilteredLabel = Label(labelframe1_2,font=("Segoe UI",9), text="Function Group", bg="old lace").grid(column=0,row=0,padx=5,pady=5,sticky='W')
FunctionFiltered = ttk.Combobox(labelframe1_2, cursor='arrow', values=ParameterFunctions, width=25,
                                state="readonly",
                                justify="left")
FunctionFiltered.grid(column=1, row=0,padx=5,)
FunctionFiltered.current(0)




FilterVariantButton = Button(labelframe1_2,font=("Segoe UI",9), text=" [x]  Variants", fg="black", bg="old lace",
                      relief="raised",command = FilterOutVariants).grid(row=0, column=2, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)


Label(labelframe1_3,font=("Segoe UI",9,'bold'), text="PARAMETERS :", bg="old lace").grid(row=0, column=0, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)
AddParameterButton = Button(labelframe1_3,font=("Segoe UI",9), text="  ADD    ", fg="white", bg="red4",
                      relief="raised",command = TrimParameters_ADDPARAMETER).grid(row=0, column=1, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)
DelParameterButton = Button(labelframe1_3,font=("Segoe UI",9), text="DELETE", fg="white", bg="red4",
                      relief="raised",command = TrimParameters_DELPARAMETER).grid(row=0, column=2, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)
EditParameterButton = Button(labelframe1_3,font=("Segoe UI",9), text="  EDIT  ", fg="white", bg="red4",
                      relief="raised",command = TrimParameters_EDITPARAMETER)
EditParameterButton.grid(row=0, column=4, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)

Label(labelframe1_3,font=("Segoe UI",9,'bold'), text="VARIANTS       :", bg="old lace").grid(row=1, column=0, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)
AddVariantButton = Button(labelframe1_3,font=("Segoe UI",9), text="  ADD    ", fg="white", bg="red4",
                      relief="raised",command = TrimParameters_ADDVARIANT).grid(row=1, column=1, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)
DelVariantButton = Button(labelframe1_3,font=("Segoe UI",9), text="DELETE", fg="white", bg="red4",
                      relief="raised",command = TrimParameters_DELVARIANT).grid(row=1, column=2, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)

EDITVARIANTButton = Button(labelframe1_3,font=("Segoe UI",9), text="  EDIT  ", fg="white", bg="red4",
                      relief="raised",command = TrimParameters_EDITVARIANT).grid(row=1, column=4, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)

Label(labelframe1_3,font=("Segoe UI",9,'bold'), text="PROJECT          :", bg="old lace").grid(row=2, column=0, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)
EditConfigurationsButton = Button(labelframe1_3,font=("Segoe UI",9), text="CONFIG", fg="white", bg="red4",
                      relief="raised",command = TrimParameters_EDITCONFIGURATIONS).grid(row=2, column=1, columnspan=1,sticky='W',padx=5, pady=5, ipadx=5, ipady=2)



check_1 = tkinter.IntVar()
check_2 = tkinter.IntVar()
check_2.set(1)
check_3 = tkinter.IntVar()
check_4 = tkinter.IntVar()
check_5 = tkinter.IntVar()
check_6 = tkinter.IntVar()
check_7 = tkinter.IntVar()
check_8 = tkinter.IntVar()
check_9 = tkinter.IntVar()
check_10 = tkinter.IntVar()
check_11 = tkinter.IntVar()
check_12 = tkinter.IntVar()

check_but_1 = tkinter.Checkbutton(labelframe1_2, text='Data Type', variable=check_1,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=1, column=0,sticky='W' )
check_but_2 = tkinter.Checkbutton(labelframe1_2, text='Resolution', variable=check_2,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=1, column=1,sticky='W' )
check_but_3 = tkinter.Checkbutton(labelframe1_2, text='SI Unit', variable=check_3,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=1, column=2,sticky='W' )
check_but_4 = tkinter.Checkbutton(labelframe1_2, text='Max Val', variable=check_4,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=2, column=0, sticky='W')
check_but_5 = tkinter.Checkbutton(labelframe1_2, text='Comments', variable=check_5,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=2, column=1,sticky='W' )
check_but_6 = tkinter.Checkbutton(labelframe1_2, text='Dimension(x)', variable=check_6,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=2, column=2,sticky='W' )
check_but_7 = tkinter.Checkbutton(labelframe1_2, text='Dimension(y)', variable=check_7,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=3, column=0,sticky='W' )
check_but_8 = tkinter.Checkbutton(labelframe1_2, text='Customer Visibility', variable=check_8,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=3, column=1,sticky='W' )
check_but_9 = tkinter.Checkbutton(labelframe1_2, text='DD Scaling', variable=check_9,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=3, column=2,sticky='W' )
check_but_10 = tkinter.Checkbutton(labelframe1_2, text='Function Group', variable=check_10,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=4, column=0,sticky='W' )
check_but_11 = tkinter.Checkbutton(labelframe1_2, text='Memory Address', variable=check_11,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=4, column=1,sticky='W' )
check_but_12 = tkinter.Checkbutton(labelframe1_2, text='Min Val', variable=check_12,onvalue=1, offvalue=0, command=UpdateFunctionFilterCheckBox,bg="old lace").grid(row=4, column=2,sticky='W' )








def UpdateVisualTable(filtereddata):
    global labelframe2 , df, PandasTable ,UnsavedChangesinDatabase,LoadedFileMsgStatus

    StatusUpdate(" ")
    labelframe2.destroy()
    labelframe2 = LabelFrame(GUITopFrame, text="", bg="old lace",
                             fg="black")
    labelframe2.pack(fill=BOTH, expand=1)

    frame = tkinter.Frame(labelframe2)
    frame.pack(fill=BOTH, expand=1)
    df = pd.DataFrame(filtereddata)
    PandasTable = Table(frame, dataframe=df, showtoolbar=False, showstatusbar=True)
    PandasTable.show()

    PropertyfilterUpdate()
    if str(FunctionFiltered.get()) == "ALL PARAMETERS":
        try:
            PandasTable = Table(frame, dataframe=df[PropertyFilterEnabled], showtoolbar=False, showstatusbar=True)
            PandasTable.show()


        except:
            ResetFields()
            ErrorPrompt("Dispaly Error", "Dataframe Coudn't be rendered on screen. Ensure proper inputs.")
            StatusUpdate("Parameters data view failed due to corrupt dataframe in Tool")

            return
    else:
            try:
                df.loc[df['FUNC_GROUP'] == str(FunctionFiltered.get())][PropertyFilterEnabled]
                PandasTable = Table(frame, dataframe=df.loc[df['FUNC_GROUP'] == str(FunctionFiltered.get())][
                    PropertyFilterEnabled], showtoolbar=False, showstatusbar=True)
                PandasTable.show()


            except:
                ResetFields()
                ErrorPrompt("Dispaly Error", "Dataframe Coudn't be rendered on screen. Ensure proper inputs.")
                StatusUpdate("Parameters data view failed due to corrupt dataframe in Tool")


                return
    if PARAMETERS_BaseCopy == PARAMETERS: UnsavedChangesinDatabase = 0
    else:
        StatusUpdate("Data Updated. Generate .xml to reflect the changes")
        UnsavedChangesinDatabase = 1
        GenerateButtonButton.configure(bg="red4")
    if LoadedFileMsgStatus==0:
        StatusUpdate("Loaded Project: {}, Revision:({},{})Maj/Min".format(str(ProjectConfig['projectname']),
                                                                          str(ProjectConfig['majorrevision']),
                                                                          str(ProjectConfig['minorrevision'])))
        LoadedFileMsgStatus=1
    #print(print(df.T.to_dict().values()))

def PromptOfUnsavedChnages():
    if UnsavedChangesinDatabase == 1:
        if messagebox.askokcancel("EXIT", "Paramater file generation required to reflect the unsaved changes.\nDo you want to discard the updates and exit?"):
            GUITopFrame.destroy()
    else : GUITopFrame.destroy()

GUITopFrame.protocol("WM_DELETE_WINDOW", PromptOfUnsavedChnages)

#testFunction()
StatusUpdate("invoked.. Parameters Tool ver "+str(ToolRev)+"\nLastUpdatedOn: "+LastUpdatedOn)
StatusUpdate("Select Parameter File to view and edit parameters.")
GUITopFrame.mainloop()



